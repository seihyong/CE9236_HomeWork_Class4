//
//  View.m
//  Shap2
//
//  Created by SEI-HYONG PARK on 7/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"


@implementation View


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
		
		int total_views = 3;
		
		CGRect b = self.bounds;
		CGFloat w = b.size.width/ total_views;
		CGFloat h = b.size.height/ total_views/ 1.5;
		
		CGRect rectview1 = CGRectMake(b.origin.x + w*0,b.origin.y,w,h);	
		view1 = [[UIView alloc] initWithFrame: rectview1];
		view1.backgroundColor = [UIColor redColor];
		[self addSubview: view1];
		
		CGRect rectview2 = CGRectMake(b.origin.x + w*1,b.origin.y,w,h);	
		view2 = [[UIView alloc] initWithFrame: rectview2];
		view2.backgroundColor = [UIColor greenColor];
		[self addSubview: view2];
		
		CGRect rectview3 = CGRectMake(b.origin.x + w*2,b.origin.y,w,h);	
		view3 = [[UIView alloc] initWithFrame: rectview3];
		view3.backgroundColor = [UIColor blueColor];
		[self addSubview: view3];
		
		/*//HOW SET IT UP W/ AN ARRAY!??
		int a[] = {0,1,2};		
		for (int i = 0; i<total_views; ++i) {
			CGRect a[i] = CGRectMake(b.origin.x + w*i,b.origin.y,w,h);
		}		
		*/
		
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
		CGPoint p = [[touches anyObject] locationInView: self];
		[UIView animateWithDuration: 1.0
							  delay: 0.0
							options: UIViewAnimationOptionCurveEaseInOut| UIViewAnimationOptionAllowUserInteraction| UIViewAnimationOptionBeginFromCurrentState
						 animations: ^{
							 if (p.x < self.bounds.size.width/3)
							 {
								 view1.center = CGPointMake(self.bounds.size.width/6,p.y);//[[touches anyObject] locationInView: self];
							 }
							 else if(p.x < self.bounds.size.width/3*2)
							 {
								 view2.center = CGPointMake(self.bounds.size.width/2,p.y);//[[touches anyObject] locationInView: self];
							 
							 }
							 else if(p.x < self.bounds.size.width/3*3)
							 {
								 view3.center = CGPointMake(self.bounds.size.width/6*5,p.y);//[[touches anyObject] locationInView: self];
								 
							 }

						 }
						 completion: NULL
		 ];
	}
}



- (void)drawRect:(CGRect)rect {
	
	//3 lines to divide up the screens
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextMoveToPoint(c, self.bounds.size.width/3, 0);
	CGContextAddLineToPoint(c, self.bounds.size.width/3, self.bounds.size.height);	

	CGContextMoveToPoint(c, self.bounds.size.width/3*2, 0);
	CGContextAddLineToPoint(c, self.bounds.size.width/3*2, self.bounds.size.height);	

	CGContextSetRGBFillColor(c, 1.0, 1.0, 1.0, 1.0);
	CGContextStrokePath(c);
	
	/*
	//behind the views
	CGRect r = CGRectMake(
						  view1.bounds.origin.x,
						  view1.bounds.origin.y,
						  view1.bounds.size.width,
						  view1.bounds.size.height
						  );
	
	CGContextRef view1pic = UIGraphicsGetCurrentContext();
	CGContextBeginPath(view1pic);
	CGContextAddEllipseInRect(view1pic, r);
	CGContextSetRGBFillColor(view1pic, 1.0, 0.0, 1.0, 0.5);
	CGContextFillPath(view1pic);
	*/
}


- (void)dealloc {
    [view1 release];
	[view2 release];
	[view3 release];
	[super dealloc];
}


@end
