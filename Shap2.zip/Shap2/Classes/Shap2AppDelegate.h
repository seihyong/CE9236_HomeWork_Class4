//
//  Shap2AppDelegate.h
//  Shap2
//
//  Created by SEI-HYONG PARK on 7/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface Shap2AppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

